import math


a = int(input("Enter number: "))



c =math.sqrt(a)

   

print("sqrt of a is  ", c )