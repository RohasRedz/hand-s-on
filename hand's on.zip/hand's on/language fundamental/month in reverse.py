month_lst = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
 'August', 'September', 'October', 'November', 'December']
              

	          

print("List in reverse: ", month_lst[::-1])