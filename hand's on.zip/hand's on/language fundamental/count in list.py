names = [2,7,4,7,2,,8,0,3,9,5]
    
a = int(input("Enter Number to count: "))

if a in names:
	print("Number of names in list are: ",names.count(a))
else:
	print("Number doesn't exist")
	          


