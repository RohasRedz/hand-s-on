names = ['Name1', 'Name2', 'Name3', 'Name4', 'Name5', 'Name6', 'Name7',
 'Name8', 'Name9', 'Name10', 'Name11', 'Name12']
              


print("Number of names in list are: ",len(names))