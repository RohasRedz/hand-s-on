month_lst = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
 'August', 'September', 'October', 'November', 'December']
              

for i in range(0,len(month_lst)):

    print("month number: {0} and month name {1}".format(i+1, month_lst[i]))
