h = eval(input("Enter INPUT: "))


a = "hiii"


b = ['hey', 'fgg']

c = ('het', 5)


d = {'one': 1, "two":2 , " three":3}


print(type(h))

print(type(a))

print(type(b))

print(type(c))

print(type(d))