
age = int(input("Enter your age: "))


if age>18:

    print("YAyy yipeee yay, GO GET MARRIED")
else:

    print("EE.. WAIT")
    
