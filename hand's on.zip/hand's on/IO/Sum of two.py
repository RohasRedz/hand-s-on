
a = eval(input("Enter number one:"))

b = eval(input("Enter number two"))


sum = a+b


print(sum)