
a = input("Enter First name:")
b = input("Enter Last name:"))





print("Full Name: ", a+b)