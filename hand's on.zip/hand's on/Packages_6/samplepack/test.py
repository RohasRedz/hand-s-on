import samplepack

print(samplepack.mathmod.add(4,5))
print(samplepack.trigmod.sine_of(45))