from samplepack import mathmod
from samplepack import trigmod