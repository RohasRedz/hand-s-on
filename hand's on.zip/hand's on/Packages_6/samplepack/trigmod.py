from math import sin, cos, tan


def sine_of(n):
    return sin(n)


def cosine_of(n):
    return cos(n)


def tangent_of(n):
    return tan(n)
