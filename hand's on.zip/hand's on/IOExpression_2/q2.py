fname = input()
lname = input()
print(fname, lname)
