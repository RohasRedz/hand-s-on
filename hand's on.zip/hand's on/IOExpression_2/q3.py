s = "Normal Style"
print("{}".format(s))
print(s)
