names = ['Kshitij', 'Apoorv', 'Amritansh']
count = 0
for i in names:
    count += 1
print(names, count)
