a = 5
b = 10
print('a: {}, b: {}'.format(a,b))
a, b = b, a
print('a: {}, b: {}'.format(a,b))