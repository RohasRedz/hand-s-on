months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
l = len(months)
for i in range(l-1,-1,-1):
    print(months[i])
