add = 2 + 3
diff = 5 - 2
mult = 7 * 5
div = 10 / 4
print(add, diff, mult, div)