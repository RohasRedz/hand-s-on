base = 10
height = 5
area = .5 * base * height
print(area)