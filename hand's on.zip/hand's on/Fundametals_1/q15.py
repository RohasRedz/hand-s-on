months = {'Jan':31, 'Feb':28, 'Mar':31, 'Apr':30, 'May':31, 'June':30, 'July':31, 'Aug':31, 'Sept':30, 'Oct':31, 'Nov':30, 'Dec':31}
print(months['Nov'])
