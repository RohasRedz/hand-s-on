types = [1, 3.2, "String", True, None]
for i in types:
	print(type(i))