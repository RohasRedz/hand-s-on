num = int(input())
print("Sq root -> {}".format(num**.5))
