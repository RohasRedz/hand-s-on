cel = int(input())
far = (9/5 * cel) + 32
print(far)
