a = int(input())
if a % 5 == 0:
	print("Divisible by 5")
else:
	print("Not Divisible by 5")
