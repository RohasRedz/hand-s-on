months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
l = len(months)
for i in range(l):
    print("Month number: {}, Month: {}".format(i+1, months[i]))
