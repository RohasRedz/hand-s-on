n1 = int(input())
n2 = int(input())
n3 = int(input())
sum = 0
if n1 == n2 or n2 == n3 or n3 == n1:
    print(sum)
else:
    sum = n1 + n2 + n3
    print(sum)
