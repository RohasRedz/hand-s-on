age = int(input("Enter your age: "))
if age >= 18:
    print("Eligible for marriage")
else:
    print("Not eligible")
