n = int(input("Enter a number: "))
if n<0:
    print("Negative")
elif n > 0:
    print("Positive")
else:
    print("Zero")
