n = int(input("Enter the number: "))
for i in range(n):
    print(n, end=" ")
