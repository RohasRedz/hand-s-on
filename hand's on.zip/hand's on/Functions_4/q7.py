n1 = int(input())
n2 = int(input())
p = lambda n1,n2:n1**n2
print(p(n1,n2))
