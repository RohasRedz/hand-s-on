def add(a,b):
    return a+b
def sub(a,b):
    return a-b
def mult(a,b):
    return a*b
def div(a,b):
    return a/b
def mod(a,b):
    return a%b

if __name__ == "__main__":
    print(add(2,3))
    print(sub(2,3))
    print(mult(2,3))
    print(div(2,3))
    print(mod(2,3))
    
