n1 = input()
n2 = input()
sum = int(n1) + int(n2)
print(sum)
