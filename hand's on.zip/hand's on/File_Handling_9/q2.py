fd = open('test.txt', 'r')
file_content = fd.read()
print(file_content)